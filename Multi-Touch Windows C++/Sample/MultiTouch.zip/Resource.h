//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WacomMT_Scribble.rc
//

#define IDI_WACOMMT_SCRIBBLE				101
#define IDI_SMALL								102

#define IDD_ABOUTBOX							110
#define IDC_ABOUT_DESC						111
#define IDC_ABOUT_CR							112

#define IDC_WACOMMT_SCRIBBLE				120

#define IDM_ABOUT								200
#define IDM_EXIT								201
#define IDM_OPTIONS_USECONFIDENCEBITS	202
#define IDM_OBSERVER							203
#define IDM_CONSUMER							204
#define IDM_RAW								205
#define IDM_BLOB								206
#define IDM_FINGER							207
#define IDM_WINDOW_HANDLES					208
#define IDM_WINDOW_RECT						209
#define IDM_SHOW_TOUCH_SIZE				210
#define IDM_SHOW_TOUCH_ID					211
#define IDM_ERASE								212
#define IDM_OPTIONS_SHOW_CAPS				214
#define IDM_OPTIONS_SHOW_POSITION_ONLY	215

#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif

#define APP_NAME								"WacomMT_Scribble"
#define APP_VERSION_STR						"5.0.0.0"
#define APP_VERSION_NUM						5,0,0,0
#define APP_COMPANY_NAME					"Wacom Technology Corp."
#define APP_COPYRIGHT						"(c) 2012-2020, Wacom Technology Corp.  All rights reserved."

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	213
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		111
#endif
#endif
